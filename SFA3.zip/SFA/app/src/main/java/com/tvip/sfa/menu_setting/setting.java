package com.tvip.sfa.menu_setting;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity; import com.tvip.sfa.Perangkat.HttpsTrustManager;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.tvip.sfa.R;
import com.tvip.sfa.menu_login.login;
import com.tvip.sfa.menu_mulai_perjalanan.scangagal_dalamrute;
import com.tvip.sfa.menu_utama.MainActivity;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class setting extends AppCompatActivity {
    LinearLayout realisasipengiriman, informasi_device, konfigurasi, editposm, keluar;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); HttpsTrustManager.allowAllSSL();
        setContentView(R.layout.activity_setting);
        sharedPreferences = getSharedPreferences("user_details", MODE_PRIVATE);

        informasi_device = findViewById(R.id.informasi_device);
        konfigurasi = findViewById(R.id.konfigurasi);
        keluar = findViewById(R.id.keluar);
        realisasipengiriman = findViewById(R.id.realisasipengiriman);
        editposm = findViewById(R.id.editposm);

        editposm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SweetAlertDialog(setting.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("Fitur Ini Belum Tersedia")
                        .setConfirmText("OK")
                        .show();
            }
        });

        realisasipengiriman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tentangperangkat = new Intent(getBaseContext(), realisasi_pengiriman.class);
                startActivity(tentangperangkat);
            }
        });


        informasi_device.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tentangperangkat = new Intent(getBaseContext(), tentang_perangkat.class);
                startActivity(tentangperangkat);
            }
        });

        konfigurasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent konfigurasi = new Intent(getBaseContext(), konfigurasi_device.class);
                startActivity(konfigurasi);

            }
        });


        keluar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SweetAlertDialog(setting.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("Apakah anda yakin?")
                        .setContentText("Anda akan keluar dari aplikasi ini")
                        .setConfirmText("Yes")
                        .setCancelText("Cancel")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.clear();
                                editor.apply();
                                Intent inetnt = new Intent(getBaseContext(), login.class);
                                inetnt.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(inetnt);
                            }
                        })
                        .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.cancel();
                            }
                        })
                        .show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        refreshActivity();
        super.onBackPressed();
    }

    public void refreshActivity() {
        Intent i = new Intent(getBaseContext(), MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
        finish();
    }
}