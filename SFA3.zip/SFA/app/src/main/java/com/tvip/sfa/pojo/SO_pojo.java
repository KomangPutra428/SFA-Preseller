package com.tvip.sfa.pojo;

public class SO_pojo {
    private final String dtmDoc;
    private final String szDocId;

    public SO_pojo(String dtmDoc, String szDocId) {
        this.dtmDoc = dtmDoc;
        this.szDocId = szDocId;
    }

    public String getDtmDoc() {
        return dtmDoc;
    }

    public String getSzDocId() {
        return szDocId;
    }
}
