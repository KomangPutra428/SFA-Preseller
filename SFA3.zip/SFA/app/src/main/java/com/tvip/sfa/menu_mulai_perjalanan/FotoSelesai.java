package com.tvip.sfa.menu_mulai_perjalanan;

import static com.tvip.sfa.menu_mulai_perjalanan.menu_pelanggan.no_surat;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.card.MaterialCardView;
import com.tvip.sfa.R;
import com.tvip.sfa.menu_utama.MainActivity;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class FotoSelesai extends AppCompatActivity {
    MaterialCardView fototampakdepan, fotochiller, fototampaksamping;
    ImageView uploadgambar, uploadgambar2, uploadgambar3;
    TextView textupload, textupload2, textupload3;

    ContentValues cv;
    Uri imageUri;
    Bitmap bitmap, bitmap2, bitmap3;

    Button lanjutkan;

    SharedPreferences sharedPreferences;

    SweetAlertDialog success, pDialog;

    private RequestQueue requestQueue;
    private RequestQueue requestQueue2;
    private RequestQueue requestQueue3;
    private RequestQueue requestQueue4;

    private RequestQueue requestQueue5;
    private RequestQueue requestQueue6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foto_selesai);
        fototampakdepan = findViewById(R.id.fototampakdepan);
        fotochiller = findViewById(R.id.fotochiller);
        fototampaksamping = findViewById(R.id.fototampaksamping);

        uploadgambar = findViewById(R.id.uploadgambar);
        uploadgambar2 = findViewById(R.id.uploadgambar2);
        uploadgambar3 = findViewById(R.id.uploadgambar3);

        textupload = findViewById(R.id.textupload);
        textupload2 = findViewById(R.id.textupload2);
        textupload3 = findViewById(R.id.textupload3);

        lanjutkan = findViewById(R.id.lanjutkan);

        lanjutkan.setOnClickListener(v -> {
            if (textupload.getVisibility() == View.VISIBLE) {
                new SweetAlertDialog(FotoSelesai.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("Upload Gambar")
                        .setConfirmText("OK")
                        .show();
            } else if (textupload2.getVisibility() == View.VISIBLE) {
                new SweetAlertDialog(FotoSelesai.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("Upload Gambar")
                        .setConfirmText("OK")
                        .show();
            } else if (textupload3.getVisibility() == View.VISIBLE) {
                new SweetAlertDialog(FotoSelesai.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("Upload Gambar")
                        .setConfirmText("OK")
                        .show();
            } else {
                pDialog = new SweetAlertDialog(FotoSelesai.this, SweetAlertDialog.PROGRESS_TYPE);
                pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
                pDialog.setTitleText("Harap Menunggu");
                pDialog.setCancelable(false);
                pDialog.show();
                postImage();
            }
        });

        fototampakdepan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv = new ContentValues();
                cv.put(MediaStore.Images.Media.TITLE, "My Picture");
                cv.put(MediaStore.Images.Media.DESCRIPTION, "From Camera");
                imageUri = getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(intent, 1);
            }
        });

        fotochiller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv = new ContentValues();
                cv.put(MediaStore.Images.Media.TITLE, "My Picture");
                cv.put(MediaStore.Images.Media.DESCRIPTION, "From Camera");
                imageUri = getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(intent, 2);
            }
        });

        fototampaksamping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv = new ContentValues();
                cv.put(MediaStore.Images.Media.TITLE, "My Picture");
                cv.put(MediaStore.Images.Media.DESCRIPTION, "From Camera");
                imageUri = getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(intent, 3);
            }
        });
    }

    private void postImage3() {
        StringRequest stringRequest2 = new StringRequest(Request.Method.POST, "https://apisec.tvip.co.id/rest_server_sfa_asa/utilitas/Mulai_Perjalanan/index_upload_selesai",
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        pDialog.dismissWithAnimation();

                        success = new SweetAlertDialog(FotoSelesai.this, SweetAlertDialog.SUCCESS_TYPE);
                        success.setContentText("Data Sudah Disimpan");
                        success.setCancelable(false);
                        success.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();

                                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK); // Call Only, if you wants to clears the activity stack else ignore it.
                                startActivity(intent);
                                finish();
                              }
                        });
                        success.show();

                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                pDialog.dismissWithAnimation();

                success = new SweetAlertDialog(FotoSelesai.this, SweetAlertDialog.SUCCESS_TYPE);
                success.setContentText("Data Sudah Disimpan");
                success.setCancelable(false);
                success.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        sDialog.dismissWithAnimation();

                        Intent intent = new Intent(getBaseContext(), MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK); // Call Only, if you wants to clears the activity stack else ignore it.
                        startActivity(intent);
                        finish();
                    }
                });
                success.show();
            }

        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<String, String>();
                String creds = String.format("%s:%s", "admin", "Databa53");
                String auth = "Basic " + Base64.encodeToString(creds.getBytes(), Base64.DEFAULT);
                params.put("Authorization", auth);
                return params;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                sharedPreferences = getSharedPreferences("user_details", MODE_PRIVATE);
                String nik_baru = sharedPreferences.getString("szDocCall", null);

                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
                String currentDateandTime2 = sdf2.format(new Date());

                String[] parts = nik_baru.split("-");
                String restnomor = parts[0];
                String restnomorbaru = restnomor.replace(" ", "");

                params.put("iId", currentDateandTime2);
                params.put("szId", mulai_perjalanan.id_pelanggan);

                params.put("szImageType", "VISIT");
                params.put("intItemNumber", "2");

                params.put("szImage", ImageToString(bitmap3));
                params.put("szCustomerId", menu_pelanggan.no_surat);

                params.put("szBranchId", restnomorbaru);
                params.put("szUserCreatedId", nik_baru);
                params.put("szUserUpdatedId", nik_baru);

                params.put("dtmCreated", currentDateandTime2);
                params.put("dtmLastUpdated", currentDateandTime2);



                return params;
            }

        };
        stringRequest2.setRetryPolicy(
                new DefaultRetryPolicy(
                        5000,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                )
        );
        if (requestQueue == null) {
            requestQueue = Volley.newRequestQueue(FotoSelesai.this);
            requestQueue.add(stringRequest2);
        } else {
            requestQueue.add(stringRequest2);
        }
    }

    private void postImage2() {
        StringRequest stringRequest2 = new StringRequest(Request.Method.POST, "https://apisec.tvip.co.id/rest_server_sfa_asa/utilitas/Mulai_Perjalanan/index_upload_selesai",
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        postImage3();
                        uploadKeServer2();
                        uploadKeServer3();
                    }

                    private void uploadKeServer3() {
                        StringRequest stringRequest2 = new StringRequest(Request.Method.POST, "https://apisec.tvip.co.id/mobile_eis_2/upload_sfa.php",
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {

                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {

                                    }
                                }) {

                            @Override
                            public Map<String, String> getHeaders() throws AuthFailureError {
                                HashMap<String, String> params = new HashMap<String, String>();
                                String creds = String.format("%s:%s", "admin", "Databa53");
                                String auth = "Basic " + Base64.encodeToString(creds.getBytes(), Base64.DEFAULT);
                                params.put("Authorization", auth);
                                return params;
                            }

                            @Override
                            protected Map<String, String> getParams() throws AuthFailureError {
                                Map<String, String> params = new HashMap<String, String>();
                                sharedPreferences = getSharedPreferences("user_details", MODE_PRIVATE);
                                String nik_baru = sharedPreferences.getString("szDocCall", null);

                                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMddHHmmss");
                                String currentDateandTime2 = sdf2.format(new Date());

                                String gambar = ImageToString(bitmap3);

                                params.put("nik", "VISIT_2" + "_" + nik_baru + "_" + no_surat + "_" + currentDateandTime2);
                                params.put("foto", gambar);
                                params.put("nama_folder", "foto_selesai_kunjungan");


                                return params;
                            }
                        };
                        stringRequest2.setRetryPolicy(
                                new DefaultRetryPolicy(
                                        5000,
                                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                                )
                        );

                        if (requestQueue2 == null) {
                            requestQueue2 = Volley.newRequestQueue(FotoSelesai.this);
                            requestQueue2.add(stringRequest2);
                        } else {
                            requestQueue2.add(stringRequest2);
                        }
                    }

                    private void uploadKeServer2() {
                        StringRequest stringRequest2 = new StringRequest(Request.Method.POST, "https://apisec.tvip.co.id/mobile_eis_2/upload_sfa.php",
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {

                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {

                                    }
                                }) {

                            @Override
                            public Map<String, String> getHeaders() throws AuthFailureError {
                                HashMap<String, String> params = new HashMap<String, String>();
                                String creds = String.format("%s:%s", "admin", "Databa53");
                                String auth = "Basic " + Base64.encodeToString(creds.getBytes(), Base64.DEFAULT);
                                params.put("Authorization", auth);
                                return params;
                            }

                            @Override
                            protected Map<String, String> getParams() throws AuthFailureError {
                                Map<String, String> params = new HashMap<String, String>();
                                sharedPreferences = getSharedPreferences("user_details", MODE_PRIVATE);
                                String nik_baru = sharedPreferences.getString("szDocCall", null);

                                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMddHHmmss");
                                String currentDateandTime2 = sdf2.format(new Date());

                                String gambar = ImageToString(bitmap2);

                                params.put("nik", "VISIT_1" + "_" + nik_baru + "_" + no_surat + "_" + currentDateandTime2);
                                params.put("foto", gambar);
                                params.put("nama_folder", "foto_selesai_kunjungan");

                                return params;
                            }
                        };
                        stringRequest2.setRetryPolicy(
                                new DefaultRetryPolicy(
                                        5000,
                                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                                )
                        );

                        if (requestQueue3 == null) {
                            requestQueue3 = Volley.newRequestQueue(FotoSelesai.this);
                            requestQueue3.add(stringRequest2);
                        } else {
                            requestQueue3.add(stringRequest2);
                        }
                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                postImage3();
            }

        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<String, String>();
                String creds = String.format("%s:%s", "admin", "Databa53");
                String auth = "Basic " + Base64.encodeToString(creds.getBytes(), Base64.DEFAULT);
                params.put("Authorization", auth);
                return params;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                sharedPreferences = getSharedPreferences("user_details", MODE_PRIVATE);
                String nik_baru = sharedPreferences.getString("szDocCall", null);

                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
                String currentDateandTime2 = sdf2.format(new Date());

                String[] parts = nik_baru.split("-");
                String restnomor = parts[0];
                String restnomorbaru = restnomor.replace(" ", "");

                params.put("iId", currentDateandTime2);
                params.put("szId", mulai_perjalanan.id_pelanggan);

                params.put("szImageType", "VISIT");
                params.put("intItemNumber", "1");

                params.put("szImage", ImageToString(bitmap2));
                params.put("szCustomerId", menu_pelanggan.no_surat);

                params.put("szBranchId", restnomorbaru);
                params.put("szUserCreatedId", nik_baru);
                params.put("szUserUpdatedId", nik_baru);

                params.put("dtmCreated", currentDateandTime2);
                params.put("dtmLastUpdated", currentDateandTime2);



                return params;
            }

        };
        stringRequest2.setRetryPolicy(
                new DefaultRetryPolicy(
                        5000,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                )
        );
        if (requestQueue4 == null) {
            requestQueue4 = Volley.newRequestQueue(FotoSelesai.this);
            requestQueue4.add(stringRequest2);
        } else {
            requestQueue4.add(stringRequest2);
        }
    }

    private void postImage() {
        StringRequest stringRequest2 = new StringRequest(Request.Method.POST, "https://apisec.tvip.co.id/rest_server_sfa_asa/utilitas/Mulai_Perjalanan/index_upload_selesai",
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        postImage2();
                        UploadKeServer();
                    }

                    private void UploadKeServer() {
                        StringRequest stringRequest2 = new StringRequest(Request.Method.POST, "https://apisec.tvip.co.id/mobile_eis_2/upload_sfa.php",
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {

                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {

                                    }
                                }) {

                            @Override
                            public Map<String, String> getHeaders() throws AuthFailureError {
                                HashMap<String, String> params = new HashMap<String, String>();
                                String creds = String.format("%s:%s", "admin", "Databa53");
                                String auth = "Basic " + Base64.encodeToString(creds.getBytes(), Base64.DEFAULT);
                                params.put("Authorization", auth);
                                return params;
                            }

                            @Override
                            protected Map<String, String> getParams() throws AuthFailureError {
                                Map<String, String> params = new HashMap<String, String>();
                                sharedPreferences = getSharedPreferences("user_details", MODE_PRIVATE);
                                String nik_baru = sharedPreferences.getString("szDocCall", null);

                                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMddHHmmss");
                                String currentDateandTime2 = sdf2.format(new Date());

                                String gambar = ImageToString(bitmap);

                                params.put("nik", "VISIT_0" + "_" + nik_baru + "_" + no_surat + "_" + currentDateandTime2);
                                params.put("foto", gambar);
                                params.put("nama_folder", "foto_selesai_kunjungan");


                                return params;
                            }
                        };
                        stringRequest2.setRetryPolicy(
                                new DefaultRetryPolicy(
                                        5000,
                                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                                )
                        );

                        if (requestQueue5 == null) {
                            requestQueue5 = Volley.newRequestQueue(FotoSelesai.this);
                            requestQueue5.add(stringRequest2);
                        } else {
                            requestQueue5.add(stringRequest2);
                        }
                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                postImage2();
            }

        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<String, String>();
                String creds = String.format("%s:%s", "admin", "Databa53");
                String auth = "Basic " + Base64.encodeToString(creds.getBytes(), Base64.DEFAULT);
                params.put("Authorization", auth);
                return params;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                sharedPreferences = getSharedPreferences("user_details", MODE_PRIVATE);
                String nik_baru = sharedPreferences.getString("szDocCall", null);

                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
                String currentDateandTime2 = sdf2.format(new Date());

                String[] parts = nik_baru.split("-");
                String restnomor = parts[0];
                String restnomorbaru = restnomor.replace(" ", "");

                params.put("iId", currentDateandTime2);
                params.put("szId", mulai_perjalanan.id_pelanggan);

                params.put("szImageType", "VISIT");
                params.put("intItemNumber", "0");

                params.put("szImage", ImageToString(bitmap));
                params.put("szCustomerId", menu_pelanggan.no_surat);

                params.put("szBranchId", restnomorbaru);
                params.put("szUserCreatedId", nik_baru);
                params.put("szUserUpdatedId", nik_baru);

                params.put("dtmCreated", currentDateandTime2);
                params.put("dtmLastUpdated", currentDateandTime2);



                return params;
            }

        };
        stringRequest2.setRetryPolicy(
                new DefaultRetryPolicy(
                        5000,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                )
        );
        if (requestQueue6 == null) {
            requestQueue6 = Volley.newRequestQueue(FotoSelesai.this);
            requestQueue6.add(stringRequest2);
        } else {
            requestQueue6.add(stringRequest2);
        }
    }

    private String ImageToString(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, baos);
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1){
            if (resultCode == Activity.RESULT_OK) {
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(
                            getContentResolver(), imageUri);
                    int width=720;
                    int height=720;
                    bitmap = Bitmap.createScaledBitmap(bitmap, width, height, true);

                    uploadgambar.setImageBitmap(bitmap);
                    textupload.setVisibility(View.GONE);

                    ViewGroup.LayoutParams paramktp = uploadgambar.getLayoutParams();

                    double sizeInDP = 226;
                    int marginInDp = (int) TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_DIP, (float) sizeInDP, getResources()
                                    .getDisplayMetrics());

                    double sizeInDP2 = 226;
                    int marginInDp2 = (int) TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_DIP, (float) sizeInDP2, getResources()
                                    .getDisplayMetrics());

                    paramktp.width = marginInDp;
                    paramktp.height = marginInDp2;
                    uploadgambar.setLayoutParams(paramktp);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else if (requestCode == 2){
            if (resultCode == Activity.RESULT_OK) {
                try {
                    bitmap2 = MediaStore.Images.Media.getBitmap(
                            getContentResolver(), imageUri);
                    int width=720;
                    int height=720;
                    bitmap2 = Bitmap.createScaledBitmap(bitmap2, width, height, true);
                    uploadgambar2.setImageBitmap(bitmap2);
                    textupload2.setVisibility(View.GONE);

                    ViewGroup.LayoutParams paramktp = uploadgambar2.getLayoutParams();

                    double sizeInDP = 226;
                    int marginInDp = (int) TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_DIP, (float) sizeInDP, getResources()
                                    .getDisplayMetrics());

                    double sizeInDP2 = 226;
                    int marginInDp2 = (int) TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_DIP, (float) sizeInDP2, getResources()
                                    .getDisplayMetrics());

                    paramktp.width = marginInDp;
                    paramktp.height = marginInDp2;
                    uploadgambar2.setLayoutParams(paramktp);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else if (requestCode == 3){
            if (resultCode == Activity.RESULT_OK) {
                try {
                    bitmap3 = MediaStore.Images.Media.getBitmap(
                            getContentResolver(), imageUri);
                    int width=720;
                    int height=720;
                    bitmap3 = Bitmap.createScaledBitmap(bitmap3, width, height, true);
                    uploadgambar3.setImageBitmap(bitmap3);
                    textupload3.setVisibility(View.GONE);

                    ViewGroup.LayoutParams paramktp = uploadgambar3.getLayoutParams();

                    double sizeInDP = 226;
                    int marginInDp = (int) TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_DIP, (float) sizeInDP, getResources()
                                    .getDisplayMetrics());

                    double sizeInDP2 = 226;
                    int marginInDp2 = (int) TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_DIP, (float) sizeInDP2, getResources()
                                    .getDisplayMetrics());

                    paramktp.width = marginInDp;
                    paramktp.height = marginInDp2;
                    uploadgambar3.setLayoutParams(paramktp);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {

    }
}