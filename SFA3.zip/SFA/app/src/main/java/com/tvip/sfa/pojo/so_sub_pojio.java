package com.tvip.sfa.pojo;

public class so_sub_pojio {
    private final String decQty;
    private final String decPrice;

    public so_sub_pojio(String decQty, String decPrice) {
        this.decQty = decQty;
        this.decPrice = decPrice;
    }

    public String getDecQty() {
        return decQty;
    }

    public String getDecPrice() {
        return decPrice;
    }
}
