package com.tvip.sfa.menu_mulai_perjalanan;

import static com.tvip.sfa.menu_mulai_perjalanan.detailscangagal_dalamrute.intItemNumbers;
import static com.tvip.sfa.menu_mulai_perjalanan.mulai_perjalanan.lastitem;
import static com.tvip.sfa.menu_mulai_perjalanan.mulai_perjalanan.outofroute;

import androidx.appcompat.app.AppCompatActivity; import com.tvip.sfa.Perangkat.HttpsTrustManager;
import androidx.fragment.app.FragmentActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.tvip.sfa.R;
import com.tvip.sfa.menu_utama.MainActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class scangagal_map extends FragmentActivity implements OnMapReadyCallback, LocationListener {
    private GoogleMap mMap;
    TextView namatoko, alamat;
    Button arahkan, lanjutkan;
    String langitude, longitude;
    LocationManager locationManager;
    SweetAlertDialog pDialog;
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); HttpsTrustManager.allowAllSSL();
        setContentView(R.layout.activity_scangagal_map);
        namatoko = findViewById(R.id.namatoko);
        alamat = findViewById(R.id.alamat);

        arahkan = findViewById(R.id.arahkan);
        lanjutkan = findViewById(R.id.lanjutkan);

        getIntent().getStringExtra("langitude");
        namatoko.setText(getIntent().getStringExtra("toko"));
        alamat.setText(getIntent().getStringExtra("alamat"));

        pDialog = new SweetAlertDialog(scangagal_map.this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        pDialog.setTitleText("Harap Menunggu");
        pDialog.setCancelable(false);
        pDialog.show();

        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                pDialog.dismissWithAnimation();
            }
        }, 10000);

        arahkan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double langitude = Double.valueOf(getIntent().getStringExtra("langitude"));
                Double longitude = Double.valueOf(getIntent().getStringExtra("longitude"));

                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse("https://maps.google.com?q="+langitude+","+longitude));
                startActivity(i);
            }
        });

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        getLocation();

        lanjutkan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(longitude != null && langitude != null){

                    Location startPoint=new Location("locationA");
                    startPoint.setLatitude(Double.valueOf(langitude));
                    startPoint.setLongitude(Double.valueOf(longitude));

                    Location endPoint=new Location("locationA");
                    endPoint.setLatitude(Double.valueOf(getIntent().getStringExtra("langitude")));
                    endPoint.setLongitude(Double.valueOf(getIntent().getStringExtra("longitude")));
                    double distance2 = startPoint.distanceTo(endPoint);
                    int value = (int) distance2;

                    if(value > 30){
                        final Dialog dialog = new Dialog(scangagal_map.this);
                        dialog.setContentView(R.layout.diluarradius);
                        dialog.setCancelable(false);

                        Button tidak = dialog.findViewById(R.id.tidak);
                        Button ya = dialog.findViewById(R.id.ya);
                        tidak.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });
                        ya.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                StringRequest stringRequest2 = new StringRequest(Request.Method.PUT, "https://apisec.tvip.co.id/rest_server_sfa_asa/utilitas/Mulai_Perjalanan/index_latlong",
                                        new Response.Listener<String>() {

                                            @Override
                                            public void onResponse(String response) {

                                            }
                                        },
                                        new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {


                                            }

                                        }) {
                                    @Override
                                    public Map<String, String> getHeaders() throws AuthFailureError {
                                        HashMap<String, String> params = new HashMap<String, String>();
                                        String creds = String.format("%s:%s", "admin", "Databa53");
                                        String auth = "Basic " + Base64.encodeToString(creds.getBytes(), Base64.DEFAULT);
                                        params.put("Authorization", auth);
                                        return params;
                                    }

                                    @Override
                                    protected Map<String, String> getParams() throws AuthFailureError {
                                        Map<String, String> params = new HashMap<String, String>();

                                        params.put("szDocId", mulai_perjalanan.id_pelanggan);
                                        params.put("szCustomerId", getIntent().getStringExtra("kode"));
                                        params.put("bVisited", "0");
                                        params.put("szLangitude", langitude);
                                        params.put("szLongitude", longitude);



                                        return params;
                                    }

                                };
                                stringRequest2.setRetryPolicy(
                                        new DefaultRetryPolicy(
                                                5000,
                                                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                                                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                                        )
                                );
                                if (requestQueue == null) {
                                    requestQueue = Volley.newRequestQueue(scangagal_map.this);
                                    requestQueue.getCache().clear();
                                    requestQueue.add(stringRequest2);
                                } else {
                                    requestQueue.add(stringRequest2);
                                }
                                Intent reason = new Intent(getBaseContext(), alasan_gagal_checkin.class);
                                startActivity(reason);
                            }
                        });
                        dialog.show();
                    } else {
                        StringRequest stringRequest2 = new StringRequest(Request.Method.PUT, "https://apisec.tvip.co.id/rest_server_sfa_asa/utilitas/Mulai_Perjalanan/index_latlong",
                                new Response.Listener<String>() {

                                    @Override
                                    public void onResponse(String response) {
                                        sf();

                                    }

                                    private void sf() {
                                        StringRequest stringRequest2 = new StringRequest(Request.Method.POST, "https://apisec.tvip.co.id/rest_server_sfa_asa/utilitas/Mulai_Perjalanan/index_DocCallItem",
                                                new Response.Listener<String>() {

                                                    @Override
                                                    public void onResponse(String response) {
//                        DocSOMDBA(s);
                                                    }
                                                }, new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {
                                                NetworkResponse response = error.networkResponse;
                                                if(response != null && response.data != null){

                                                }else{
                                                    String errorMessage=error.getClass().getSimpleName();
                                                    if(!TextUtils.isEmpty(errorMessage)){

                                                    }
                                                }
                                            }

                                        }) {
                                            @Override
                                            public Map<String, String> getHeaders() throws AuthFailureError {
                                                HashMap<String, String> params = new HashMap<String, String>();
                                                String creds = String.format("%s:%s", "admin", "Databa53");
                                                String auth = "Basic " + Base64.encodeToString(creds.getBytes(), Base64.DEFAULT);
                                                params.put("Authorization", auth);
                                                return params;
                                            }

                                            @Override
                                            protected Map<String, String> getParams() throws AuthFailureError {
                                                Map<String, String> params = new HashMap<String, String>();


                                                String rest2 = detailscangagal_dalamrute.alasangagalscan.getText().toString();
                                                String[] parts2 = rest2.split("-");
                                                String restnomor2 = parts2[0];

                                                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                                String currentDateandTime2 = sdf2.format(new Date());

                                                params.put("szDocId", mulai_perjalanan.id_pelanggan);
                                                params.put("intItemNumber", lastitem);

                                                params.put("szCustomerId", detailscangagal_dalamrute.code.getText().toString());

                                                params.put("dtmStart", currentDateandTime2);
                                                params.put("dtmFinish", currentDateandTime2);

                                                params.put("bVisited", "1");
                                                params.put("bSuccess", "0");


                                                params.put("szFailReason", "");
                                                params.put("szLangitude", MainActivity.latitude);
                                                params.put("szLongitude", MainActivity.longitude);
                                                params.put("bOutOfRoute", outofroute);
                                                params.put("szRefDocId", "");

                                                params.put("bScanBarcode", "0");

                                                params.put("szReasonIdCheckin", "");
                                                params.put("szReasonFailedScan", restnomor2);
                                                params.put("decRadiusDiff", "0");








                                                return params;
                                            }

                                        };
                                        stringRequest2.setRetryPolicy(
                                                new DefaultRetryPolicy(
                                                        5000,
                                                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                                                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                                                )
                                        );
                                        RequestQueue requestQueue2 = Volley.newRequestQueue(scangagal_map.this);
                                        requestQueue2.getCache().clear();
                                        requestQueue2.add(stringRequest2);
                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {


                                    }

                                }) {
                            @Override
                            public Map<String, String> getHeaders() throws AuthFailureError {
                                HashMap<String, String> params = new HashMap<String, String>();
                                String creds = String.format("%s:%s", "admin", "Databa53");
                                String auth = "Basic " + Base64.encodeToString(creds.getBytes(), Base64.DEFAULT);
                                params.put("Authorization", auth);
                                return params;
                            }

                            @Override
                            protected Map<String, String> getParams() throws AuthFailureError {
                                Map<String, String> params = new HashMap<String, String>();

                                params.put("szDocId", mulai_perjalanan.id_pelanggan);
                                params.put("bVisited", "1");
                                params.put("szCustomerId", getIntent().getStringExtra("kode"));
                                params.put("szLangitude", langitude);
                                params.put("szLongitude", longitude);



                                return params;
                            }

                        };
                        stringRequest2.setRetryPolicy(
                                new DefaultRetryPolicy(
                                        5000,
                                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                                )
                        );
                        RequestQueue requestQueue2 = Volley.newRequestQueue(scangagal_map.this);
                        requestQueue2.getCache().clear();
                        requestQueue2.add(stringRequest2);
                        Intent reason = new Intent(getBaseContext(), menu_pelanggan.class);
                        startActivity(reason);
                    }
                } else {
                    Toast.makeText(getBaseContext(),
                            "Lokasi Tidak Terdeteksi" ,
                            Toast.LENGTH_LONG).show();
                }

            }
        });



    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        Double langitude = Double.valueOf(getIntent().getStringExtra("langitude"));
        Double longitude = Double.valueOf(getIntent().getStringExtra("longitude"));

        // Add a marker in Sydney and move the camera
        LatLng zoom = new LatLng(langitude, longitude);

        mMap.addMarker(new MarkerOptions().position(zoom).title(getIntent().getStringExtra("toko")));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(zoom));

        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(zoom, 20));
    }

    @SuppressLint("MissingPermission")
    private void getLocation() {

        try {
            locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,5000,5, scangagal_map.this);

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void onLocationChanged(Location location) {
        try {
            Geocoder geocoder = new Geocoder(scangagal_map.this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);

            longitude = String.valueOf(location.getLongitude());
            langitude = String.valueOf(location.getLatitude());



        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}